<?php

class Payslip extends HR_Controller
{
	protected $active_nav = NAV_PAYSLIP;
	protected $tab_title = 'Payslip';

	public function __construct()
	{
		parent::__construct();
		$this->load->model('Payslip_model', 'payslip');
		$this->load->model('Employee_model', 'employee');
	}

	public function index()
	{
		$this->import_plugin_script(['bootstrap-datepicker/js/bootstrap-datepicker.min.js']);
		$this->import_page_script(['manage-payslip.js']);
		$this->generate_page('payslip/generate', [
			'title' => 'Generate payslip'
		]);
	}

	public function generate()
	{
		$input = elements(['month', 'employee_number'], $this->input->get());
		if(!$this->employee->exists($input['employee_number'])){
			redirect('payslip');
		}
		$date = [];
		$range = phase($input['month']);
		$employee_data = $this->employee->get($input['employee_number']);
		$data = $this->payslip->calculate($input['employee_number'], $range[0], $range[1]);
		if(is_numeric($data)){
			redirect("my_payslip/view/{$data}?employee_number={$employee_data['id']}");
		}
		$this->generate_page('payslip/manage', [
			'title' => 'Manage payslip',
			'data' => $data,
			'employee_data' => $employee_data,
			'from' =>  $range[0],
			'to' =>  $range[1],
			'month' => $input['month']
		]);
	}

	public function store()
	{
		$input = elements(['month', 'employee_number' ,'adjustment'], $this->input->post());
		if($this->payslip->create($input['employee_number'], $input['month'], $input['adjustment'])){
			redirect('payslip');
		}
	}

}